-- ==============================================================================
-- PRINTOPIA SOLUTIONS - SUPABASE DATABASE SCHEMA & RLS POLICIES
-- ==============================================================================

-- 1. Create quotation_requests Table
CREATE TABLE IF NOT EXISTS public.quotation_requests (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
    full_name TEXT NOT NULL,
    company_name TEXT,
    phone TEXT NOT NULL,
    email TEXT,
    product_name TEXT NOT NULL,
    estimated_quantity INTEGER,
    message TEXT,
    source_page TEXT,
    status TEXT DEFAULT 'pending' NOT NULL
);

-- 2. Indexing for fast queries
CREATE INDEX IF NOT EXISTS idx_quotation_requests_created_at 
ON public.quotation_requests(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_quotation_requests_status 
ON public.quotation_requests(status);

-- 3. Enable Row Level Security (RLS)
ALTER TABLE public.quotation_requests ENABLE ROW LEVEL SECURITY;

-- 4. RLS Policy: Allow anyone (anonymous or authenticated) to submit quotation requests
DROP POLICY IF EXISTS "Allow public insert for quotation requests" ON public.quotation_requests;

CREATE POLICY "Allow public insert for quotation requests"
ON public.quotation_requests
FOR INSERT
TO public
WITH CHECK (true);

-- 5. RLS Policy: Allow authenticated users to view quotation requests (for Admin dashboard)
DROP POLICY IF EXISTS "Allow authenticated select for quotation requests" ON public.quotation_requests;

CREATE POLICY "Allow authenticated select for quotation requests"
ON public.quotation_requests
FOR SELECT
TO authenticated
USING (true);

-- 6. Grant Permissions
GRANT INSERT, SELECT ON public.quotation_requests TO anon, authenticated;
