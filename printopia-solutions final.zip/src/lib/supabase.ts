import { createClient, SupabaseClient } from '@supabase/supabase-js';
import type { Database } from '../types/database';

const rawUrl = import.meta.env.VITE_SUPABASE_URL;
const rawKey = import.meta.env.VITE_SUPABASE_ANON_KEY || import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

const supabaseUrl = rawUrl?.trim() || '';
const supabaseAnonKey = rawKey?.trim() || '';

const isValidUrl = (url: string): boolean => {
  return url.startsWith('http://') || url.startsWith('https://');
};

let supabaseInstance: SupabaseClient<Database> | null = null;

export const isSupabaseConfigured = (): boolean => {
  return isValidUrl(supabaseUrl) && supabaseAnonKey.length > 0;
};

export const getSupabase = (): SupabaseClient<Database> => {
  if (!isSupabaseConfigured()) {
    throw new Error(
      'Supabase is not configured yet. Please set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in your environment.'
    );
  }

  if (!supabaseInstance) {
    supabaseInstance = createClient<Database>(supabaseUrl, supabaseAnonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
      },
    });
  }

  return supabaseInstance;
};

// Export singleton instance or null
export const supabase = isSupabaseConfigured()
  ? createClient<Database>(supabaseUrl, supabaseAnonKey)
  : null;
