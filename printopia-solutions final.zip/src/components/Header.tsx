import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, ArrowRight } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { images } from '../data/imageMap';

interface HeaderProps {
  onRequestQuote: () => void;
}

const navItems = [
  { label: 'Home', id: 'home', path: '/' },
  { label: 'Products', id: 'products', path: '/products' },
  { label: 'About', id: 'about', path: '/about' },
  { label: 'Printing Guide', id: 'guide', path: '/printing-guide' },
  { label: 'Contact', id: 'contact', path: '/contact' },
];

export default function Header({ onRequestQuote }: HeaderProps) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 30) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Prevent background scrolling when mobile menu drawer is open
  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [mobileMenuOpen]);

  const getActiveId = () => {
    const path = location.pathname;
    if (path === '/' || path === '/home') return 'home';
    if (path.startsWith('/products')) return 'products';
    if (path.startsWith('/about')) return 'about';
    if (path.startsWith('/printing-guide')) return 'guide';
    if (path.startsWith('/contact')) return 'contact';
    return 'home';
  };

  const currentActive = getActiveId();

  const handleNavClick = (path: string) => {
    navigate(path);
    setMobileMenuOpen(false);
    // Smooth scroll to top of viewport on page transition
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header
      id="app-header"
      role="banner"
      className={`fixed top-0 left-0 right-0 z-50 h-[76px] transition-all duration-300 ease-in-out border-b border-white/10 ${
        scrolled
          ? 'bg-[#0C3855]/92 backdrop-blur-[18px] shadow-lg shadow-black/15'
          : 'bg-[#0C3855]/75 backdrop-blur-[18px] shadow-sm'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 h-full">
        <div className="flex items-center justify-between h-full">
          
          {/* Logo Brand Mark (Left) */}
          <button
            id="header-logo-btn"
            onClick={() => handleNavClick('/')}
            className="flex items-center cursor-pointer group text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/50 rounded-lg p-1 -ml-1"
            aria-label="Printopia Solutions Home"
          >
            <img
              src={images.logo}
              alt="Printopia Logo"
              width={150}
              height={45}
              className="w-auto h-[32px] sm:h-[42px] object-contain transition-transform duration-300 group-hover:scale-105"
              loading="eager"
              decoding="async"
              onError={(e) => {
                e.currentTarget.src = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="150" height="45" viewBox="0 0 150 45"><rect width="100%" height="100%" fill="none"/><text x="10" y="28" font-family="sans-serif" font-weight="bold" font-size="16" fill="%23BED7EB">PRINTOPIA</text></svg>';
              }}
            />
          </button>

          {/* Desktop Navigation Links (Center) */}
          <nav
            id="desktop-nav"
            role="navigation"
            aria-label="Main Navigation"
            className="hidden md:flex items-center space-x-1 bg-white/10 p-1 rounded-full border border-white/15 backdrop-blur-md"
          >
            {navItems.map((item) => {
              const isActive = currentActive === item.id;
              return (
                <button
                  id={`nav-item-${item.id}`}
                  key={item.id}
                  onClick={() => handleNavClick(item.path)}
                  aria-current={isActive ? 'page' : undefined}
                  className={`relative px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider transition-all duration-200 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/50 ${
                    isActive
                      ? 'text-white'
                      : 'text-white/75 hover:text-white hover:bg-white/10'
                  }`}
                >
                  {isActive && (
                    <motion.span
                      layoutId="active-nav-bg"
                      className="absolute inset-0 bg-[#0C7D8D] shadow-md rounded-full -z-10 border border-white/20"
                      transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                    />
                  )}
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Right Side Buttons: Request Quotation + WhatsApp (Right) */}
          <div className="hidden md:flex items-center space-x-3.5">
            {/* WhatsApp Icon */}
            <a
              id="whatsapp-header-link"
              href={`https://wa.me/919432436942?text=${encodeURIComponent("Hello Printopia Solutions, I would like to know more about your healthcare printing services.")}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-10 h-10 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 flex items-center justify-center text-white shadow-sm hover:shadow-md transition-all duration-300 hover:scale-105 group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/50"
              title="Chat with Printing Experts"
              aria-label="Contact via WhatsApp"
            >
              <svg className="w-5 h-5 text-[#BED7EB] group-hover:text-white transition-colors duration-300" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" />
              </svg>
            </a>

            {/* Request Quotation */}
            <button
              id="cta-request-quotation"
              onClick={onRequestQuote}
              className="px-5 py-2.5 bg-gradient-to-r from-[#0C7D8D] to-[#085a66] hover:from-[#09606c] hover:to-[#06424b] text-white text-xs font-extrabold tracking-wider uppercase rounded-xl shadow-md hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0 transition-all duration-300 flex items-center justify-center space-x-2 border border-white/20 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/50"
              aria-label="Request a Quotation"
            >
              <span>Request Quotation</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Mobile Menu Toggle (Right) */}
          <div className="flex items-center md:hidden space-x-2.5">
            <a
              id="whatsapp-mobile-link"
              href={`https://wa.me/919432436942?text=${encodeURIComponent("Hello Printopia Solutions, I would like to know more about your healthcare printing services.")}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-9 h-9 rounded-xl bg-white/10 border border-white/20 flex items-center justify-center text-white shadow-sm"
              aria-label="Contact Printopia Solutions via WhatsApp"
            >
              <svg className="w-4.5 h-4.5 text-[#BED7EB]" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" />
              </svg>
            </a>
            <button
              id="mobile-menu-toggle"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-xl text-white hover:bg-white/10 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/50"
              aria-expanded={mobileMenuOpen}
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer Navigation (Full-screen Slide Overlay) */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            id="mobile-nav-overlay"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.25, ease: 'easeInOut' }}
            className="md:hidden fixed inset-x-0 top-[76px] bg-[#0C3855]/98 backdrop-blur-2xl border-b border-white/10 shadow-2xl overflow-y-auto max-h-[calc(100vh-76px)] z-40"
          >
            <div className="px-6 pt-5 pb-8 space-y-3">
              {navItems.map((item) => {
                const isActive = currentActive === item.id;
                return (
                  <button
                    id={`mobile-nav-${item.id}`}
                    key={item.id}
                    onClick={() => handleNavClick(item.path)}
                    aria-current={isActive ? 'page' : undefined}
                    className={`block w-full text-left px-5 py-3.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
                      isActive
                        ? 'bg-[#0C7D8D] text-white shadow-md border border-white/20'
                        : 'text-white/80 hover:bg-white/10 hover:text-white'
                    }`}
                  >
                    {item.label}
                  </button>
                );
              })}
              <div className="pt-4 border-t border-white/10">
                <button
                  id="mobile-cta-request-quote"
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onRequestQuote();
                  }}
                  className="flex items-center justify-center space-x-2 w-full py-4 bg-gradient-to-r from-[#0C7D8D] to-[#085a66] text-white text-xs font-extrabold uppercase tracking-widest rounded-xl shadow-lg border border-white/20 cursor-pointer active:scale-95 transition-all"
                >
                  <span>Request Quotation</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
