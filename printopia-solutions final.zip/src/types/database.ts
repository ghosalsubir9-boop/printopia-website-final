export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      quotation_requests: {
        Row: {
          id: string
          created_at: string
          full_name: string
          company_name: string | null
          phone: string
          email: string | null
          product_name: string
          estimated_quantity: number | null
          message: string | null
          source_page: string | null
          status: string
        }
        Insert: {
          id?: string
          created_at?: string
          full_name: string
          company_name?: string | null
          phone: string
          email?: string | null
          product_name: string
          estimated_quantity?: number | null
          message?: string | null
          source_page?: string | null
          status?: string
        }
        Update: {
          id?: string
          created_at?: string
          full_name?: string
          company_name?: string | null
          phone?: string
          email?: string | null
          product_name?: string
          estimated_quantity?: number | null
          message?: string | null
          source_page?: string | null
          status?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}
